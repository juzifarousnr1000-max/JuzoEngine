// MeineEngine v0.1 - Kern: EGL + GLES3 + Touch + ImGui-Editor-Grundgerüst
#include <android_native_app_glue.h>
#include <android/input.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <cmath>
#include "imgui.h"
#include "backends/imgui_impl_android.h"
#include "backends/imgui_impl_opengl3.h"

struct Engine {
    android_app* app = nullptr;
    EGLDisplay dpy = EGL_NO_DISPLAY; EGLSurface surf = EGL_NO_SURFACE; EGLContext ctx = EGL_NO_CONTEXT;
    int w = 0, h = 0;
    bool ready = false;
    GLuint prog = 0, vao = 0, vbo = 0, ibo = 0; GLint uMvp = -1;
    float rx = 0.4f, ry = 0.0f, speed = 0.8f; bool spin = true;
    bool dragging = false, pendingDown = false; float lx = 0, ly = 0;
};

// --- Mini-Mathe (spaltenweise 4x4) ---
static void mul(const float* a, const float* b, float* r) {
    for (int c = 0; c < 4; c++) for (int i = 0; i < 4; i++) {
        float s = 0; for (int k = 0; k < 4; k++) s += a[k * 4 + i] * b[c * 4 + k]; r[c * 4 + i] = s; }
}
static void ident(float* m) { for (int i = 0; i < 16; i++) m[i] = (i % 5 == 0); }

static GLuint shader(GLenum t, const char* s) {
    GLuint o = glCreateShader(t); glShaderSource(o, 1, &s, nullptr); glCompileShader(o); return o;
}

static bool initGL(Engine& e) {
    e.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY); eglInitialize(e.dpy, nullptr, nullptr);
    const EGLint ca[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
    EGLConfig cfg; EGLint n = 0; eglChooseConfig(e.dpy, ca, &cfg, 1, &n);
    if (n < 1) return false;
    e.surf = eglCreateWindowSurface(e.dpy, cfg, e.app->window, nullptr);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    e.ctx = eglCreateContext(e.dpy, cfg, EGL_NO_CONTEXT, xa);
    if (!eglMakeCurrent(e.dpy, e.surf, e.surf, e.ctx)) return false;
    eglSwapInterval(e.dpy, 1);
    eglQuerySurface(e.dpy, e.surf, EGL_WIDTH, &e.w); eglQuerySurface(e.dpy, e.surf, EGL_HEIGHT, &e.h);

    const char* vs = "#version 300 es\nlayout(location=0) in vec3 p; layout(location=1) in vec3 c;"
        "uniform mat4 mvp; out vec3 v; void main(){v=c; gl_Position=mvp*vec4(p,1.0);}";
    const char* fs = "#version 300 es\nprecision mediump float; in vec3 v; out vec4 o; void main(){o=vec4(v,1.0);}";
    e.prog = glCreateProgram();
    glAttachShader(e.prog, shader(GL_VERTEX_SHADER, vs)); glAttachShader(e.prog, shader(GL_FRAGMENT_SHADER, fs));
    glLinkProgram(e.prog); e.uMvp = glGetUniformLocation(e.prog, "mvp");

    float vtx[8 * 6];
    for (int i = 0; i < 8; i++) {
        float x = (i & 1) ? 1.f : -1.f, y = (i & 2) ? 1.f : -1.f, z = (i & 4) ? 1.f : -1.f;
        float* v = vtx + i * 6; v[0] = x; v[1] = y; v[2] = z; v[3] = x * .5f + .5f; v[4] = y * .5f + .5f; v[5] = z * .5f + .5f;
    }
    const unsigned char idx[36] = {0,1,3,0,3,2, 4,5,7,4,7,6, 0,2,6,0,6,4, 1,3,7,1,7,5, 0,1,5,0,5,4, 2,3,7,2,7,6};
    glGenVertexArrays(1, &e.vao); glBindVertexArray(e.vao);
    glGenBuffers(1, &e.vbo); glBindBuffer(GL_ARRAY_BUFFER, e.vbo); glBufferData(GL_ARRAY_BUFFER, sizeof(vtx), vtx, GL_STATIC_DRAW);
    glGenBuffers(1, &e.ibo); glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, e.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 24, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 24, (void*)12);

    IMGUI_CHECKVERSION(); ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr;
    ImGui::StyleColorsDark(); ImGui::GetStyle().ScaleAllSizes(2.5f); io.FontGlobalScale = 2.5f;
    ImGui_ImplAndroid_Init(e.app->window); ImGui_ImplOpenGL3_Init("#version 300 es");
    e.ready = true; return true;
}

static void termGL(Engine& e) {
    if (e.ready) { ImGui_ImplOpenGL3_Shutdown(); ImGui_ImplAndroid_Shutdown(); ImGui::DestroyContext(); }
    if (e.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(e.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (e.ctx != EGL_NO_CONTEXT) eglDestroyContext(e.dpy, e.ctx);
        if (e.surf != EGL_NO_SURFACE) eglDestroySurface(e.dpy, e.surf);
        eglTerminate(e.dpy);
    }
    e.dpy = EGL_NO_DISPLAY; e.ctx = EGL_NO_CONTEXT; e.surf = EGL_NO_SURFACE; e.ready = false;
}

static void drawFrame(Engine& e) {
    ImGuiIO& io = ImGui::GetIO();
    ImGui_ImplOpenGL3_NewFrame(); ImGui_ImplAndroid_NewFrame(); ImGui::NewFrame();
    if (e.pendingDown) { e.dragging = !io.WantCaptureMouse; e.pendingDown = false; }

    ImGui::SetNextWindowPos(ImVec2(20, 20), ImGuiCond_Once);
    ImGui::Begin("Szene");
    ImGui::Text("FPS: %.0f", io.Framerate);
    ImGui::Checkbox("Automatisch drehen", &e.spin);
    ImGui::SliderFloat("Tempo", &e.speed, 0.f, 3.f);
    if (ImGui::Button("Zuruecksetzen")) { e.rx = 0.4f; e.ry = 0.f; }
    ImGui::TextDisabled("Wuerfel per Finger drehen");
    ImGui::End();
    ImGui::Render();

    if (e.spin) e.ry += io.DeltaTime * e.speed;
    glViewport(0, 0, e.w, e.h); glClearColor(.10f, .12f, .16f, 1); glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    float asp = (float)e.w / (float)e.h, f = 1.f / tanf(0.5f * 1.0f), n = 0.1f, fa = 50.f;
    float P[16] = {0}, T[16], X[16], Y[16], A[16], B[16], M[16];
    P[0] = f / asp; P[5] = f; P[10] = (fa + n) / (n - fa); P[11] = -1; P[14] = 2 * fa * n / (n - fa);
    ident(T); T[14] = -5.f;
    ident(X); X[5] = cosf(e.rx); X[9] = -sinf(e.rx); X[6] = sinf(e.rx); X[10] = cosf(e.rx);
    ident(Y); Y[0] = cosf(e.ry); Y[8] = sinf(e.ry); Y[2] = -sinf(e.ry); Y[10] = cosf(e.ry);
    mul(P, T, A); mul(A, X, B); mul(B, Y, M);
    glUseProgram(e.prog); glUniformMatrix4fv(e.uMvp, 1, GL_FALSE, M);
    glBindVertexArray(e.vao); glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_BYTE, nullptr);

    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(e.dpy, e.surf);
}

static int32_t onInput(android_app* app, AInputEvent* ev) {
    Engine* e = (Engine*)app->userData;
    if (!e->ready) return 0;
    ImGui_ImplAndroid_HandleInputEvent(ev);
    if (AInputEvent_getType(ev) == AINPUT_EVENT_TYPE_MOTION) {
        float x = AMotionEvent_getX(ev, 0), y = AMotionEvent_getY(ev, 0);
        int a = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
        if (a == AMOTION_EVENT_ACTION_DOWN) { e->pendingDown = true; e->lx = x; e->ly = y; }
        else if (a == AMOTION_EVENT_ACTION_MOVE && e->dragging) { e->ry += (x - e->lx) * 0.01f; e->rx += (y - e->ly) * 0.01f; e->lx = x; e->ly = y; }
        else if (a == AMOTION_EVENT_ACTION_UP || a == AMOTION_EVENT_ACTION_CANCEL) { e->dragging = false; e->pendingDown = false; }
        return 1;
    }
    return 0;
}

static void onCmd(android_app* app, int32_t cmd) {
    Engine* e = (Engine*)app->userData;
    if (cmd == APP_CMD_INIT_WINDOW && app->window) initGL(*e);
    else if (cmd == APP_CMD_TERM_WINDOW) termGL(*e);
}

void android_main(android_app* app) {
    Engine e; e.app = app; app->userData = &e; app->onAppCmd = onCmd; app->onInputEvent = onInput;
    while (true) {
        int ev; android_poll_source* src;
        while (ALooper_pollOnce(e.ready ? 0 : -1, nullptr, &ev, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) { termGL(e); return; }
        }
        if (e.ready) drawFrame(e);
    }
}
